import {StyleSheet} from 'react-native';

//Styles Login page
const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: 54, 
    backgroundColor:'#ecf0f1',
  },
});

export default styles

