import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import React from 'react';
import CadastroUsuario from './src/CadastroUsuario';



const App = () => {
  return <CadastroUsuario />;
};

export default App;
  

